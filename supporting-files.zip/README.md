# Foreguild Close — original supporting material

Proposal dated 6 November 2026, Asia/Bangkok. This archive contains only our original proposal, arithmetic, synthetic controls and exports. No competitor source code, document, asset, private data, wallet or secret is included. No network, wallet or live contract call is made by these scripts.

## Run from the unzipped folder (standard-library Python 3)

```
python3 model.py --check foreguild-final-operating-plan.html --self-test
python3 verify.py
python3 market_math.py
python3 model.py --export refreshed-model
```

The two HTML deliverables are standalone. The operating plan does not require this archive. The separate competitive audit is outside this archive because it is a review artifact, not part of the proposed business.

## What the checker actually does

model.py computes a 12-month expected-value base schedule, fixed/variable costs, full-year totals, three monthly scenarios, early-closure downside path, reserve bridge and worked scalar arithmetic. It parses marked VISIBLE numeric cells/spans in the actual supplied HTML. It compares their text, including signs, to recalculated values. --self-test alters a visible month-12 profit value in memory and requires that edit to fail; it never changes the original file. Missing required cells also fail. It does not validate every unmarked prose number or the truth of assumptions.

209 checked numeric occurrences / 201 distinct required values in the delivered plan.

## Assumptions and accounting

- Price 600 USDC; worker reward 300; management net revenue 300; platform direct cost 100; contribution 200 before acquisition/fixed costs. Principal statutory presentation may instead report gross revenue 600 and worker COGS 300; profit is unchanged. This is not an accounting opinion.
- Base 404 accepted packs in year one; 80 in month 12; 14 agencies active in month 12. Client retention 95% monthly, agency retention 98%; new agency acquisition 350, incremental client onboarding 75. These are unvalidated.
- Fixed 6,500/month for months 1–6 and conditional 9,000/month afterward. The scheduled higher capacity is prohibited unless actual demand/quality/capital/policy gates pass.
- Funding required 90,000, not secured. Setup 18,000. Quarantined: 15,000 commercial reserve, 5,000 LP principal at risk, 5,000 shutdown. Customer escrow is never treasury funding.
- Year-one operating loss 24,854; setup-inclusive cash-budget loss 42,854; end funding resources 47,146; minimum 36,702 in month 9; minimum headroom above the 25,000 quarantine 11,702. First positive operating month 10 does NOT mean cumulative payback.
- The funding balance includes reserved/possibly locked LP principal at book cost; it is not entirely spendable cash. Base LP trading P&L is zero as an assumption. Full 5,000 LP-loss stress leaves minimum resources 31,702 and 6,702 headroom above the original conservative floor. The full LP-loss stress triggers the $35,000 growth pause, so the base growth schedule cannot simply continue unchanged under it. LP returns/losses are separately reported outside OP60 to avoid the decision market's payout being part of its own oracle metric. Operating governance labor/rewards/gas are charged.
- The 20/pack loss provision is assumed paid within the month for conservative cash budgeting. Actual financial books distinguish provision, cash claim and restricted reserve. Transfers to reserves are not P&L expense. No tax, FX/depeg loss or catastrophic legal/security loss is assumed; those remain risks and launch conditions.
- The downside stop CSV models 1/2/3 accepted packs, higher review costs and failed day-90 gate; month 4 pays 5,000 wind-down, then no new spending/orders. Retained funding 47,357.50. Monthly-scenario downside is a separate 20-pack stress run rate, not a claim to keep operating for 12 months after the exit gate fails.

## Evidence limits

verify.py uses hand-made fictional transaction/invoice fixtures. It demonstrates required control behavior; it cannot prove genuine source identity, invoice authenticity, input completeness, model accuracy, real-world throughput or buyer value.

market_math.py tests proportional scalar settlement, negative-profit shifting, clipping, Invalid, unselected-branch zero payout and quote normalization. It does not implement or test deployed Seer contracts. Actual addresses, units, question templates, oracle bonds/timeouts, trade depth, payout behavior, mandate execution, security and legal arrangements must be independently reviewed before a live pilot. No live market or customer is claimed.

No competitor scripts were executed in preparing this work. Vendor capabilities cited in the HTML are vendor statements, not independently verified demand or endorsement.
