#!/usr/bin/env python3
"""Original pure-arithmetic conditional scalar examples; NOT Seer integration tests."""
from fractions import Fraction as F

def scalar(op,invalid=False):
 if invalid:return (F(0),F(0),F(1)) # Low, High, Invalid
 shifted=min(100_000,max(0,op+25_000));h=F(shifted,100_000)
 return (1-h,h,F(0))

def child_base_value(op,child_parent,actual_parent,leg=1,invalid=False):
 return scalar(op,invalid)[leg] if child_parent==actual_parent else F(0)

def main():
 assert scalar(-5000)==(F(4,5),F(1,5),F(0))
 assert scalar(0)==(F(3,4),F(1,4),F(0))
 assert scalar(-30000)==(F(1),F(0),F(0))
 assert scalar(100000)==(F(0),F(1),F(0))
 assert scalar(500,True)==(F(0),F(0),F(1))
 for branch in ['A','B','Abort','Parent Invalid']:
  assert sum(int(outcome==branch) for outcome in ['A','B','Abort','Parent Invalid'])==1
 assert child_base_value(10000,'A','B')==0 # Not a refund.
 assert child_base_value(10000,'A','Abort')==0
 assert child_base_value(-5000,'A','A')==F(1,5)
 assert child_base_value(123,'A','A',2,True)==1
 # Raw base-currency prices can reverse the comparison: normalize in parent units.
 qa,qb=F(265,1000),F(225,1000);pa,pb=F(1,5),F(4,5)
 assert pa*qa<pb*qb and (pa*qa)/pa>(pb*qb)/pb
 # Invalid is a separate leg; q is conditional on a valid outcome.
 invalid=F(1,100);high=qa*(1-invalid);low=(1-qa)*(1-invalid)
 assert high/(high+low)==qa
 assert -25000+100000*qa==1500
 assert (-25000+100000*qa)-(-25000+100000*F(235,1000))==3000
 print('PASS: scalar/conditional accounting checks, including loss bounds, Invalid and inactive-branch zero payout.')
 print('Not live quotes, contract execution, a security review or a causal validation.')
if __name__=='__main__':main()
