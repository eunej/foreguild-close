#!/usr/bin/env python3
"""Original Foreguild Close planning arithmetic. No network, contracts or private inputs.
python3 model.py --check ../foreguild-final-operating-plan.html
python3 model.py --export .
Checks the *visible* marked numeric contents of the actual HTML, not embedded JSON.
"""
from decimal import Decimal as D, ROUND_HALF_UP
from pathlib import Path
from html.parser import HTMLParser
import argparse, csv, json, math

ASSUMPTIONS = {
 'price':600, 'worker':300, 'variable':100, 'client_retention':'0.95',
 'agency_retention':'0.98', 'new_client_cost':75, 'new_agency_cost':350,
 'initial_cash':90000, 'setup':18000, 'refund_reserve':15000,
 'lp_principal':5000, 'winddown_reserve':5000,
 'base_packs':[2,4,8,12,18,25,33,42,50,60,70,80],
 'base_agencies':[2,3,4,5,6,7,8,9,10,11,12,14],
 'fixed_early':6500, 'fixed_later':9000,
}
VARIABLE = {'Intake and scope':15,'Compute, RPC and storage':8,
 'Independent review (36 minutes at $50/hour)':30,'Support':10,
 'Settlement':2,'Failed attempts allocated over accepted packs':15,
 'Expected refund/defect loss provision':20}
FIXED = {'Maintainer capacity':2400,'Operations capacity':1800,
 'Administration and legal retainer':600,'Infrastructure minimums':600,
 'Governance development, attestation, oracle/gas and forecast rewards':400,
 'Security and independent finance review':700}
assert sum(VARIABLE.values())==100 and sum(FIXED.values())==6500

def base_rows():
 a=ASSUMPTIONS; cash=D(a['initial_cash']-a['setup']); prev_p=prev_a=D(0); rows=[]
 for i,(pi,ai) in enumerate(zip(a['base_packs'],a['base_agencies']),1):
  p,ag=D(pi),D(ai)
  newp=p-D(a['client_retention'])*prev_p
  newa=ag-D(a['agency_retention'])*prev_a
  cac=newp*a['new_client_cost']+newa*a['new_agency_cost']
  gross=p*a['price']; worker=p*a['worker']; fee=gross-worker
  var=p*a['variable']; con=fee-var
  fixed=D(a['fixed_early'] if i<=6 else a['fixed_later'])
  op=con-fixed-cac; cash+=op
  rows.append(dict(month=i,packs=p,agencies=ag,new_clients=newp,new_agencies=newa,
    billings=gross,workers=worker,revenue=fee,variable=var,contribution=con,
    acquisition=cac,fixed=fixed,op=op,cash=cash))
  prev_p,prev_a=p,ag
 return rows

def downside_rows():
 # A failure path, NOT twelve months of spending despite a failed day-90 gate.
 a=ASSUMPTIONS; cash=D(a['initial_cash']-a['setup']); rows=[]; pp=pa=D(0)
 for m,(p,ag) in enumerate([(1,1),(2,1),(3,2)],1):
  p,ag=D(p),D(ag); cac=(p-D('.90')*pp)*75+(ag-D('.95')*pa)*350
  op=p*(600-300-160)-6500-cac;cash+=op
  rows.append(dict(month=m,packs=p,agencies=ag,acquisition=cac,op=op,cash=cash));pp,pa=p,ag
 cash-=5000 # prepaid wind-down envelope actually spent
 rows.append(dict(month=4,packs=D(0),agencies=D(0),acquisition=D(0),op=D(-5000),cash=cash))
 return rows

def values():
 a=ASSUMPTIONS; rows=base_rows(); v={}
 def put(k,x):v[k]=D(str(x))
 for k in ('price','worker','variable','initial_cash','setup','refund_reserve','lp_principal','winddown_reserve','fixed_early','fixed_later'):
  put('a.'+k,a[k])
 put('unit.fee',300);put('unit.contribution',200);put('unit.markup_percent',100);put('unit.fee_share',50)
 put('capital.restricted',25000);put('capital.usable_after_setup',47000)
 for i,(k,x) in enumerate(VARIABLE.items()):put('variable.'+str(i),x)
 for i,(k,x) in enumerate(FIXED.items()):put('fixed.'+str(i),x)
 for r in rows:
  for k,x in r.items():put(f'm{r["month"]}.{k}',x)
 for group,rs in [('q1',rows[:3]),('y1',rows)]:
  for k in ('packs','billings','workers','revenue','variable','contribution','acquisition','fixed','op'):
   put(f'{group}.{k}',sum(r[k] for r in rs))
 put('y1.cash',rows[-1]['cash']);put('y1.minimum_cash',min(r['cash'] for r in rows))
 put('y1.total_cash_loss',a['initial_cash']-rows[-1]['cash'])
 put('y1.headroom',min(r['cash'] for r in rows)-25000)
 put('y1.first_positive_month',next(r['month'] for r in rows if r['op']>=0));put('y1.minimum_balance_month',min(rows,key=lambda r:r['cash'])['month'])
 put('y1.lp_loss_stress',-5000);put('y1.lp_stress_minimum',min(r['cash'] for r in rows)-5000);put('y1.lp_stress_headroom',min(r['cash'] for r in rows)-30000)
 put('q1.setup_inclusive_cost',18000-sum(r['op'] for r in rows[:3]))
 for name,packs,var,fixed,cac in [('down',20,160,6500,900),('base',80,100,9000,rows[-1]['acquisition']),('up',140,90,15000,2500)]:
  p=D(packs);fee=p*300;variable=p*var;con=fee-variable;op=con-D(fixed)-D(cac)
  for k,x in dict(packs=p,billings=p*600,workers=p*300,revenue=fee,variable=variable,contribution=con,fixed=fixed,acquisition=cac,op=op).items():put('s.'+name+'.'+k,x)
 put('break_even.packs',47);put('break_even.agencies',10)
 put('break_even.replacement_cost',D(47)*D('.05')*75+D(10)*D('.02')*350)
 put('break_even.op',D(47)*200-9000-v['break_even.replacement_cost'])
 dr=downside_rows();put('down.closed_cash',dr[-1]['cash']);put('down.cash_loss',90000-dr[-1]['cash'])
 put('sensitivity.extra_audit_y1',404*60)
 put('sensitivity.audit_m12_op',rows[-1]['op']-80*60)
 # Example scalar payoff/decision arithmetic; no live market quotes.
 put('market.lower_op',-25000);put('market.upper_op',75000);put('market.offset',25000);put('market.range',100000)
 put('market.A_bid',D('.265'));put('market.A_ask',D('.275'));put('market.B_bid',D('.225'));put('market.B_ask',D('.235'))
 put('market.A_conservative_op',D('.265')*100000-25000)
 put('market.B_optimistic_op',D('.235')*100000-25000)
 put('market.gap',v['market.A_conservative_op']-v['market.B_optimistic_op'])
 put('market.reward_and_ops',1200);put('market.minimum_gap',2400)
 return v

class Numbers(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.stack=[];self.found=[]
 def handle_starttag(self,tag,attrs):
  attrs=dict(attrs)
  self.stack.append([tag,attrs.get('data-model'),[]])
 def handle_endtag(self,tag):
  # Rendered numeric spans/tds have no nested markup; tolerate surrounding document.
  match=next((i for i in range(len(self.stack)-1,-1,-1) if self.stack[i][0]==tag),None)
  if match is None:return
  entries=self.stack[match:];self.stack=self.stack[:match]
  for _,key,text in entries:
   if key:self.found.append((key,''.join(text)))
 def handle_data(self,s):
  for entry in self.stack:
   if entry[1]:entry[2].append(s)

def as_number(s):
 s=s.strip().replace(',','').replace('$','').replace('USDC','').replace('%','').strip()
 if s.startswith('(') and s.endswith(')'):s='-'+s[1:-1]
 return D(s.replace('−','-'))

def check_html(text):
 p=Numbers();p.feed(text);expected=values();errors=[];seen=set()
 for key,text in p.found:
  seen.add(key)
  if key not in expected:errors.append(f'Unknown data-model key {key}');continue
  try:actual=as_number(text)
  except Exception:errors.append(f'Not numeric: {key}={text!r}');continue
  rounded=expected[key].quantize(D('.01'),rounding=ROUND_HALF_UP)
  if actual!=expected[key] and actual!=rounded:errors.append(f'{key}: HTML={actual}, computed={expected[key]}')
 # All visible financial tables, scalar example and reserve numbers must be represented.
 required={k for k in expected if k.startswith(('a.','unit.','capital.','variable.','fixed.','s.','break_even.','market.','q1.','y1.','down.','sensitivity.'))}
 required|={f'm{i}.{k}' for i in range(1,13) for k in ('packs','agencies','revenue','contribution','acquisition','fixed','op','cash')}
 errors += [f'Missing visible checked value: {k}' for k in sorted(required-seen)]
 return errors,len(p.found),len(seen)

def export(path):
 path=Path(path);path.mkdir(parents=True,exist_ok=True)
 (path/'assumptions.json').write_text(json.dumps(ASSUMPTIONS,indent=2)+'\n')
 for name,rows in [('base-monthly',base_rows()),('downside-stop',downside_rows())]:
  with (path/(name+'.csv')).open('w') as f:
   w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 (path/'computed-values.json').write_text(json.dumps({k:str(v) for k,v in values().items()},indent=2)+'\n')

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--check',type=Path);ap.add_argument('--export',type=Path);ap.add_argument('--self-test',action='store_true');args=ap.parse_args()
 if args.export:export(args.export)
 if args.check:
  text=args.check.read_text();errors,count,unique=check_html(text)
  if errors:raise SystemExit('FAIL\n'+'\n'.join(errors))
  print(f'PASS: {count} visible numeric cells/spans; {unique} distinct computed values; actual HTML parsed.')
  if args.self_test:
   import re
   mutated,n=re.subn(r'(<(?:td|span)[^>]*data-model="m12.op"[^>]*>)[^<]+',r'\g<1>$5,204.50',text,count=1)
   assert n==1 and check_html(mutated)[0], 'Mutation was not detected'
   print('PASS: deliberate edit to visible month-12 profit is rejected (original file unchanged).')
 if not args.check and not args.export:print(json.dumps({k:str(v) for k,v in values().items()},indent=2))
