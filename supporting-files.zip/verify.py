#!/usr/bin/env python3
"""Original synthetic acceptance-control demo. No live chain, model or private data.
This verifies relationships in supplied fixtures, not the truth/completeness of inputs.
"""
from copy import deepcopy
USDC='native-USDC-fixture' # Deliberately not a live token address.
INVOICES={
 'INV-A':{'units':100_000_000,'counterparty':'Customer A'},
 'INV-B':{'units':100_000_000,'counterparty':'Customer B'},
}
EVENTS={
 ('Base','synthetic-tx-1',0):{'units':100_000_000,'token':USDC,'sender':'wallet-A'},
 ('Base','synthetic-tx-2',0):{'units':40_000_000,'token':USDC,'sender':'wallet-B'},
}
IDENTITIES={'wallet-A':'Customer A','wallet-B':'Customer B'} # Buyer approved, not discovered from an amount.
REFERENCES={('Base','synthetic-tx-1',0):{'INV-A'},('Base','synthetic-tx-2',0):{'INV-B'}}

class Rejected(ValueError):pass

def verify(rows,events=EVENTS,identities=IDENTITIES,references=REFERENCES):
 used={}; paid={};seen=set()
 for row in rows:
  if row.get('status')=='unknown':
   if not row.get('reason'):raise Rejected('unknown requires an explicit reason')
   continue
  key=tuple(row['event']);inv=row['invoice'];units=row['allocated_units']
  if (key,inv) in seen:raise Rejected('duplicate event/invoice allocation')
  seen.add((key,inv))
  if key not in events or inv not in INVOICES:raise Rejected('source locator absent')
  e=events[key];i=INVOICES[inv]
  if key[0]!='Base' or e['token']!=USDC:raise Rejected('unsupported chain/token')
  if type(units) is not int or units<=0:raise Rejected('positive integer units required')
  if inv not in references.get(key,set()):raise Rejected('amount/date is not an invoice reference')
  if identities.get(e['sender'])!=i['counterparty']:raise Rejected('missing/conflicting identity map')
  used[key]=used.get(key,0)+units;paid[inv]=paid.get(inv,0)+units
  if used[key]>e['units']:raise Rejected('event consumed more than once / overallocated')
  if paid[inv]>i['units']:raise Rejected('invoice overallocated')
 for row in rows:
  if row.get('status')=='unknown':continue
  actual='fully_paid' if paid[row['invoice']]==INVOICES[row['invoice']]['units'] else 'partial'
  if row['status']!=actual:raise Rejected('partial payment falsely reported as fully paid')
 return {'allocated_units':sum(used.values()),'supported_invoices':len(paid)}

GOOD=[{'event':['Base','synthetic-tx-1',0],'invoice':'INV-A','allocated_units':100_000_000,'status':'fully_paid'},
      {'event':['Base','synthetic-tx-2',0],'invoice':'INV-B','allocated_units':40_000_000,'status':'partial'}]

def main():
 tests=[]
 assert verify(GOOD)=={'allocated_units':140_000_000,'supported_invoices':2}
 tests.append('Exact approved-reference, identity and integer allocation passes')
 def bad(label,rows,**kwargs):
  try:verify(rows,**kwargs)
  except Rejected:tests.append(label+' rejected')
  else:raise AssertionError(label+' incorrectly accepted')
 x=deepcopy(GOOD[:1]);x[0]['invoice']='INV-B';bad('Same amount / wrong invoice',x)
 bad('Duplicate event / invoice',GOOD+[deepcopy(GOOD[0])])
 x=deepcopy(GOOD);x[1]['status']='fully_paid';bad('Partial claimed fully paid',x)
 x=deepcopy(GOOD);x[0]['allocated_units']+=1;bad('One-unit overallocation',x)
 bad('Missing approved identity',GOOD,identities={})
 x=deepcopy(EVENTS);x[tuple(GOOD[0]['event'])]['token']='wrong-token';bad('Wrong token',GOOD,events=x)
 x=deepcopy(GOOD);x[0]['allocated_units']=100_000_000.0;bad('Floating-point unit input',x)
 assert verify([{'status':'unknown','reason':'specific invoice reference unavailable'}])['supported_invoices']==0
 tests.append('Explicit unknown is not counted as a paid invoice')
 for t in tests:print('PASS:',t)
 print(f'{len(tests)} synthetic control tests passed. Not demand, chain, model-accuracy, security or completeness proof.')

if __name__=='__main__':main()
